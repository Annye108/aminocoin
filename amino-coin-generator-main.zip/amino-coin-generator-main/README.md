# amino-coin-generator

EN: Free amino coin generator script using python

ES: Script generador de amino monedas gratuito en python

## Download

https://github.com/ViktorSky/amino-coin-generator/archive/refs/heads/main.zip

## Requirements

##### • websocket-client
##### • requests
##### • flask
##### • json_minify
##### • pytz
##### • amino.fix
